package com.java.aop;

public class Boarding {

	public void assignProject() {
		System.out.println("Project to be Assigned...Please meet relevant manager...");
	}
}
