package com.java.meeting;

public class Meeting {

	public void scheduleMeeting() {
		System.out.println("Meeting getting Scheduled at 10.30 AM ");
	}
}
