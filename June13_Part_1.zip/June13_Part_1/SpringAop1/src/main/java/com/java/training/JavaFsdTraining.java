package com.java.training;

public class JavaFsdTraining {
	
	public void showInfo(String batch1) {
		System.out.println("Java FSD Training is Happening for batch1...");
	}
	
	public void location() {
		System.out.println("Its for Online Training...");
	}
}
