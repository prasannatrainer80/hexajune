package com.hexaware.around;

public class Boarding {

	public void assignProject(String student) {
		System.out.println("Meet Relevant Manager for this..." +student);
	}
	
	public void location() {
		System.out.println("It Chennai...");
	}
	public void company() {
		System.out.println("Its Hexaware...");
	}
}
