package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbJpaDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbJpaDemoApplication.class, args);
	}

}
