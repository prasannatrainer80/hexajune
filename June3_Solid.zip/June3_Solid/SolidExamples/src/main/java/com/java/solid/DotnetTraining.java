package com.java.solid;

public class DotnetTraining {
	public void show() {
		System.out.println("Hi Its from Peers Technologies New Dotnet Batch...");
	}
	
	public void timing() {
		System.out.println("Provision for fast track and Realtime course...");
	}
}
