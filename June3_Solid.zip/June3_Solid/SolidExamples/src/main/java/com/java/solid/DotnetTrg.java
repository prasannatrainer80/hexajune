package com.java.solid;

public class DotnetTrg {
	public void trainerName() {
		System.out.println("Trainer name is Santosh...");
	}
	public void city() {
		System.out.println("City is From Chennai...");
	}
}
