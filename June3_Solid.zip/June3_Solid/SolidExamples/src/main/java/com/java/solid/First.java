package com.java.solid;

public class First {

	public void show() {
		System.out.println("Welcome to Class First Show Method...");
	}
}


