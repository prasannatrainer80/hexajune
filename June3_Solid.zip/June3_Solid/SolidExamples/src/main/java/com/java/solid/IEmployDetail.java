package com.java.solid;

public interface IEmployDetail {
	void name();
	void paymentDetails();
	void pfDetails();
	void paySlips();
}
