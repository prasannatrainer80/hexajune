package com.java.solid;

public class IspExample {

}
