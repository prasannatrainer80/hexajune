package com.java.solid;

public class JavaTraining {
	public void show() {
		System.out.println("Hi New Java Batch from Dr. Ratna sir at 3 AM IST...");
	}
	
	public void timing() {
		System.out.println("Having Provision for Online and Offline...");
	}
}
