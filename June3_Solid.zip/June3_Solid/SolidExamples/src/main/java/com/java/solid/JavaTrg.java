package com.java.solid;

public class JavaTrg {
	public void trainerName() {
		System.out.println("Trainer Name is Prasanna...");
	}
	
	public void city() {
		System.out.println("Location is from Hyderabad...");
	}
}
