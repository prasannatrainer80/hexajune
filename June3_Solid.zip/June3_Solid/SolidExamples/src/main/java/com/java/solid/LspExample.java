package com.java.solid;

public class LspExample {
	public static void main(String[] args) {
		First obj = new Second();
		obj.show();
	}
}
