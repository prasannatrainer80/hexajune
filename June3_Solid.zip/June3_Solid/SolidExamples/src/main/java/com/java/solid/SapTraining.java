package com.java.solid;

public class SapTraining {
	public void show() {
		System.out.println("Its Sap Training for ABAP and BW model");
	}
	
	public void timing() {
		System.out.println("Moring 8 to evening 8 weekends for Employees");
	}
}
