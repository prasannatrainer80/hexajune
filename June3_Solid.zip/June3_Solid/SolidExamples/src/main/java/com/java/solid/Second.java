package com.java.solid;

public class Second extends First {
	public void show() {
		System.out.println("Show Method from Class Second...");
	}
}
