package com.java.solid.dip;

public interface ITrainerData {
	void name();
	void city();
	void email();
}
