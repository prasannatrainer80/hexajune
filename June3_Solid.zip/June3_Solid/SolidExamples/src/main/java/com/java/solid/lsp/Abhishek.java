package com.java.solid.lsp;

public class Abhishek extends Details {

	@Override
	void showInfo() {
		System.out.println("Hi I am Abhishek...");
	}

}
