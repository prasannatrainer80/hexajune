package com.java.solid.lsp;

public class Sandiya extends Details {

	@Override
	void showInfo() {
		System.out.println("Hi I am Sandiya...");
	}

}
