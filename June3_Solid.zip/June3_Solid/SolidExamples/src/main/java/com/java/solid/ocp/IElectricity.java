package com.java.solid.ocp;

public interface IElectricity {
	String payment(double billAmount);
}
