package com.java.solid.ocp;

public interface ITraining {
	void info();
	void timing();
}
