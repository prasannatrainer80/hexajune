package com.java.spr;

public interface Hello {
	void sayHello(String name);
}
