package com.java.spr;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class Family {

	private String city;
	private String state;
	
	
}
