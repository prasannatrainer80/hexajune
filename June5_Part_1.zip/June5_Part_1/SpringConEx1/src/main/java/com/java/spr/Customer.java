package com.java.spr;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Customer {

	private String customerName;
	private double billAmount;
	
	
}
