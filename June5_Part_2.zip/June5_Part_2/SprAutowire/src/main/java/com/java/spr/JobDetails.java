package com.java.spr;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class JobDetails {

	private String job;
	private String company;
	private String location;
	
}
