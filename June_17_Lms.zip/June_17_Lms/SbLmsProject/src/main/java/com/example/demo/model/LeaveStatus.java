package com.example.demo.model;

public enum LeaveStatus {
	PENDING, APPROVED, DENIED
}
