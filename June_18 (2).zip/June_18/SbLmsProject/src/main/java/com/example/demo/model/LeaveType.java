package com.example.demo.model;

public enum LeaveType {
	EL, PL, ML
}
