package com.java.hexa;

@FunctionalInterface
public interface FinEx1 {
	String test(String name);
}

