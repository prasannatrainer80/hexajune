package com.java.hexa;

public interface FinEx2 {
	String topic(String course);
}
