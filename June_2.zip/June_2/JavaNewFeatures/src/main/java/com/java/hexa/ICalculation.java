package com.java.hexa;

public interface ICalculation {
	int calc(int a, int b);
}
