package com.java.hexa;

public interface IGreeting {
	String greeMe(String name);
}
