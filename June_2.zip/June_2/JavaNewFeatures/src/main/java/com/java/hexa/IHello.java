package com.java.hexa;

public interface IHello {
	void sayHello();
}
