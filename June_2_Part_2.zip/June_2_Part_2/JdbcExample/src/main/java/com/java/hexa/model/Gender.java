package com.java.hexa.model;

public enum Gender {
	MALE, FEMALE
}
