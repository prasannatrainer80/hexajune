package com.java.hexa;

import org.junit.Test;

public class AppTest {

  @Test
  public void testMain() {
    App.main(null);
  }

}
