import { Employ } from './employ';

describe('Employ', () => {
  it('should create an instance', () => {
    expect(new Employ()).toBeTruthy();
  });
});
